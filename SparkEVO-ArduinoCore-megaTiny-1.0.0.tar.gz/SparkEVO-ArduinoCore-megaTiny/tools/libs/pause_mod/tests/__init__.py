#!/usr/bin/env python

#
# Unittests for pause
#
